# My-Shop — Next.js + Tailwind MVP (Demo)

Bu paket, **telefon üzerinden** deploy edebilmen için hazırlanmış minimal bir Next.js + Tailwind e-ticaret MVP'idir.
İçinde ürün listeleme, ürün detay, demo ödeme linki API'si (provider entegrasyonu için yama gerekli) bulunur.

## İçindekiler
- `pages/` — Next.js sayfaları
- `pages/api/create-payment-link.js` — demo ödeme linki oluşturma
- `data/products.json` — ürün verileri (JSON)
- `public/images/` — ürün görselleri (placeholder)
- `styles/globals.css` — Tailwind css
- `package.json`, `tailwind.config.js`, `postcss.config.js`

## Telefon üzerinden hızlı deploy (Vercel + GitHub mobile)
1. GitHub uygulamasını telefona yükle (App Store / Play Store).
2. Yeni bir repository oluştur (örneğin `my-shop`).
3. GitHub uygulaması veya bir mobil kod editörü (ya da GitHub web) ile bu zip içindeki dosyaları repo'ya yükle.
   - Alternatif: GitHub web (mobile) -> repo -> "Add file" -> "Upload files"
4. Vercel uygulamasını telefona yükle ve GitHub hesabını bağla.
5. Vercel'de "New Project" -> GitHub repo'nu seç -> Deploy.
6. Vercel dashboard üzerinden Environment Variables ekle (ör. `NEXT_PUBLIC_BASE_URL`).
7. Domain aldıktan sonra Vercel'de "Domains" kısmına domaini ekle ve yönlendirme talimatlarını takip et.

## Ödeme sağlayıcı entegrasyonu
Şu anda proje demo ödeme sayfasına yönlendiriyor. Gerçek entegrasyon için:
- PayTR veya iyzico ile başvur (merchant id, key).
- `pages/api/create-payment-link.js` içinde provider dokümantasyonuna göre payload ve hash/sig oluştur.
- Gerekirse webhook endpoint'leri ekle (`pages/api/webhook.js`) ve sipariş durumlarını güncelle.

## Görselleri değiştirme
`public/images/hasir1.jpg` ve `public/images/kase1.jpg` adlarıyla görselleri ekleyin veya `data/products.json` içindeki `images` alanını güncelleyin.

## Nasıl yardım alırsın?
- Eğer istersen, ben ödeme sağlayıcı entegrasyonu için gerekli `create-payment-link` kodunu sağlayabilirim; sadece hangi sağlayıcıyı kullanacağını söylemen yeterli.
- Domain ayarları ve DNS yönlendirme adımlarını telefondan nasıl yapacağına dair adım adım rehber vereceğim.