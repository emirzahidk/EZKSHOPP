export default function Fail(){
  return (
    <div className="container mx-auto p-6">
      <h1 className="text-2xl font-semibold">Ödeme Başarısız</h1>
      <p>Ödeme gerçekleştirilmedi. Lütfen tekrar deneyin.</p>
    </div>
  );
}