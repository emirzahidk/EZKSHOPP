export default function Success(){
  return (
    <div className="container mx-auto p-6">
      <h1 className="text-2xl font-semibold">Ödeme Başarılı</h1>
      <p>Teşekkürler! Siparişiniz alındı. (Demo)</p>
    </div>
  );
}