import { useRouter } from "next/router";
export default function MockPayment(){
  const router = useRouter();
  const { order, amount } = router.query;
  return (
    <div className="container mx-auto p-6">
      <h1 className="text-2xl font-semibold">Demo Ödeme Sayfası</h1>
      <p>Sipariş: {order}</p>
      <p>Tutar: {amount}</p>
      <div className="mt-4">
        <a href="/payment/success" className="bg-green-600 text-white px-4 py-2 rounded">Ödeme Başarılı (Demo)</a>
        <a href="/payment/fail" className="ml-3 bg-red-600 text-white px-4 py-2 rounded">Ödeme Başarısız (Demo)</a>
      </div>
    </div>
  );
}