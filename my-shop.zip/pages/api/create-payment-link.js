import axios from "axios";
import products from "../../data/products.json";

export default async function handler(req, res){
  if(req.method !== "POST"){
    return res.status(405).end();
  }
  const body = req.body || {};
  const product = products.find(p=>p.id===body.productId);
  if(!product) return res.status(400).json({error:"Ürün bulunamadı"});
  const qty = Number(body.qty || 1);
  const amount = (product.price * qty).toFixed(2);

  try{
    const demoPaymentUrl = `${process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000'}/payment/mock?order=order_${Date.now()}&amount=${amount}`;
    return res.redirect(302, demoPaymentUrl);
  }catch(err){
    console.error(err);
    return res.status(500).json({error:"Ödeme linki oluşturulamadı"});
  }
}