import { useRouter } from "next/router";
import products from "../../data/products.json";
import { useState } from "react";
import Link from "next/link";

export default function Product(){
  const router = useRouter();
  const { id } = router.query;
  const p = products.find(x=>x.id===id);
  const [qty, setQty] = useState(1);

  if(!p) return <div className="p-6">Ürün bulunamadı</div>;

  return (
    <div className="container mx-auto p-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <img src={p.images[0]} className="w-full h-96 object-cover rounded" alt={p.title} />
        <div>
          <h1 className="text-2xl font-semibold">{p.title}</h1>
          <p className="text-gray-600 mt-2">{p.description}</p>
          <div className="mt-4">
            <div className="text-2xl font-bold">{p.price} {p.currency}</div>
            <div className="mt-3 flex items-center gap-2">
              <label>Miktar:</label>
              <input type="number" value={qty} min="1" onChange={(e)=>setQty(Number(e.target.value))} className="w-20 border rounded px-2 py-1"/>
            </div>
            <form action="/api/create-payment-link" method="POST" className="mt-6">
              <input type="hidden" name="productId" value={p.id} />
              <input type="hidden" name="qty" value={qty} />
              <button className="bg-green-600 text-white px-4 py-2 rounded">Satın Al</button>
            </form>
            <div className="mt-4">
              <Link href="/">← Mağazaya dön</Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}