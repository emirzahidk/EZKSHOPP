import Link from "next/link";
import products from "../data/products.json";

export default function Home(){
  return (
    <div className="container mx-auto p-6">
      <h1 className="text-3xl font-semibold mb-6">Mağazam — Öne Çıkan Ürünler</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {products.map(p => (
          <div key={p.id} className="border rounded-lg p-4 shadow-sm">
            <img src={p.images[0]} alt={p.title} className="w-full h-48 object-cover rounded" />
            <h2 className="mt-3 font-medium">{p.title}</h2>
            <p className="text-sm text-gray-600">{p.short}</p>
            <div className="mt-4 flex items-center justify-between">
              <div className="text-lg font-bold">{p.price} {p.currency}</div>
              <Link href={`/product/${p.id}`} className="bg-blue-600 text-white px-3 py-1 rounded">İncele</Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}